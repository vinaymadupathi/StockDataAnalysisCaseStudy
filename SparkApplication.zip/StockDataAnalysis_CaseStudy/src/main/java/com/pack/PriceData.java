package com.pack;

import java.io.Serializable;

public class PriceData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4363235334810983147L;
	
	private double close;
	private double high;
	private double low;
	private double open;
	private double volume;
	
	public double getClose() {
		return close;
	}
	
	public void setClose(double value) {
		close = value;
	}
	
	public double getHigh() {
		return high;
	}
	
	public void setHigh(double value) {
		high = value;
	}

	public double getLow() {
		return low;
	}
	
	public void setLow(double value) {
		low = value;
	}
	
	public double getOpen() {
		return open;
	}
	
	public void setOpen(double value) {
		open = value;
	}

	public double getVolume() {
		// If Volume is negative, multiplying with -1 to get the absolute value
		if(volume < 0)
			return volume * -1;
		
		return volume;
	}
	
	public void setVolume(double value) {
		volume = value;
	}
}