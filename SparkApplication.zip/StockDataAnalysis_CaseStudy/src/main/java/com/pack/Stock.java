package com.pack;

import java.io.Serializable;

public class Stock implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5486275802577622028L;
	
	private String symbol;
	private String timestamp;
	private PriceData priceData;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String value)	{
		symbol = value;
	}
	
	public String getTimestamp() {
		return timestamp;
	}
	
	public void setTimestamp(String value) {
		timestamp = value;
	}
	public PriceData getPriceData() {
		return priceData;
	}
	
    @Override
    public String toString() {
        return "Stock [symbol=" + symbol + ", timestamp=" + timestamp + ", close=" + priceData.getClose() + ", high=" + priceData.getHigh()
                + ", low=" + priceData.getLow() + ", open=" + priceData.getOpen() + ", volume=" + priceData.getVolume() + "]";
    }
}
