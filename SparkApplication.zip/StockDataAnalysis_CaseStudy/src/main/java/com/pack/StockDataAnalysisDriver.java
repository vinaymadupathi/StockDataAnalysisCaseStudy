package com.pack;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import scala.Tuple2;
import scala.Tuple3;

public class StockDataAnalysisDriver {
	
	// Main method for Stock Data analysis
	public static void main(String[] args) {		
    	// Verify if required arguments such as broker id , topics and group id are provided, otherwise exit with error 
        if (args.length < 3) {
            System.err.println("Usage: StockDataAnalysis <brokers> <topics> <groupId>\n");
            System.exit(1);
        }
		
		// Take inputs from command line arguments - broker, groupId and topics
		String brokers = args[0];
		String topics = args[1];		
		String groupId = args[2];		
		
		// Create Spark Configuration and java streaming context object with batch interval of 1 minute
		SparkConf conf = new SparkConf().setAppName("StockDataAnalysis").setMaster("local[*]");
		JavaStreamingContext context = new JavaStreamingContext(conf, Durations.minutes(1));
		
		// Set log level to WARN
		context.sparkContext().setLogLevel("WARN");
	
		// Create topic set by splitting based on comma if multiple topics are provided
		Set<String> topicSet = new HashSet<String>(Arrays.asList(topics.split(",")));
		
		// Create kafka parameters map with configurations - brokers, groupid, key and value deserializer classes
		Map<String,Object> kafkaParams = new HashMap<String, Object>();
		kafkaParams.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, brokers);
		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		kafkaParams.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
		kafkaParams.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
		
		// Create Kafka integration with Spark Streaming subscribing to specified topicSet and kafka parameters to create DStreams 
		JavaInputDStream<ConsumerRecord<String, JsonNode>> messages = KafkaUtils.createDirectStream(context, 
				LocationStrategies.PreferConsistent(), ConsumerStrategies.Subscribe(topicSet, kafkaParams));
		
		// Perform mapToPair transformation to return paired DStream with symbol as a key and Stock object as a value
		JavaPairDStream<String, Stock> dStreamStockData = messages.mapToPair(new PairFunction<ConsumerRecord<String, JsonNode>, String, Stock>() {
			private static final long serialVersionUID = 1L;

			// overriding the default call method
			// Creating Stock object using ObjectMapper class and returning a tuple with symbol as a key and Stock obj as a value
            @Override
            public Tuple2<String, Stock> call(ConsumerRecord<String, JsonNode> record) throws JsonProcessingException {
                ObjectMapper objectMapper = new ObjectMapper();
                Stock stObject = objectMapper.treeToValue(record.value(), Stock.class);
                System.out.println(stObject.toString());
                return new Tuple2<String, Stock>(stObject.getSymbol(), stObject);
            }
        }).cache();
        
		// Analysis 1. Calculate Simple Moving Average Closing price of each stock
		calculateSimpleMovingAverage(dStreamStockData);
		
		// Analysis 2. Calculate Stock with maximum profit ( Average closing price - Average opening price)
		calculateStockWithMaximumProfit(dStreamStockData);
		
		// Analysis 3. Calculate Stock with high total traded volume which is more likely to be purchased
		calculateStockWithHighTradedVolume(dStreamStockData);		
		
		// Start Spark streaming context
		context.start();
		try {
			context.awaitTermination();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private static void calculateSimpleMovingAverage(JavaPairDStream<String, Stock> dStreamStockData) {
		// Create mapToPair transformation to get symbol as a key and (closingPrice, 1) as a value
		dStreamStockData.mapToPair(f -> new Tuple2<String, Tuple2<Double, Integer>>
					(f._1, new Tuple2<Double, Integer>(f._2.getPriceData().getClose(), 1)))
		// Applying reduceByKeyAndWindow transformation on Stock data DStream with Window size 10 minutes and Sliding interval of 5 minutes
        .reduceByKeyAndWindow(new Function2<Tuple2<Double, Integer>, Tuple2<Double, Integer>, Tuple2<Double, Integer>>(){
			private static final long serialVersionUID = -7189226093834978183L;

			// Returning new tuple with summing up closingPrice and counts
			@Override
			public Tuple2<Double, Integer> call(Tuple2<Double, Integer> v1, Tuple2<Double, Integer> v2) throws Exception {
				return new Tuple2<Double, Integer>(v1._1 + v2._1, v1._2+v2._2);
			}        	
        }, Durations.minutes(10), Durations.minutes(5))
        // For each RDD, get simple moving average closing price by dividing total closing price by count for each stock.
        .foreachRDD(new VoidFunction<JavaPairRDD<String, Tuple2<Double, Integer>>>(){
			private static final long serialVersionUID = -7021168181886240641L;

			// Now each RDD with symbol has summation of closing price and number of transactions/count for each stock
			// Here we are calculating simple moving average of closing price by dividing closing price total by count for each stock
			@Override
			public void call(JavaPairRDD<String, Tuple2<Double, Integer>> t) throws Exception {
				List<Tuple2<String, Tuple2<Double, Integer>>> list = t.collect();
				for(Tuple2<String, Tuple2<Double, Integer>> item : list)
				{
					double closingPrice = item._2._1 /item._2._2;
					System.out.println("moving average for stock " + item._1 + " is " + closingPrice);
				}
			}        	
        });
	}
	
	private static void calculateStockWithMaximumProfit(JavaPairDStream<String, Stock> dStreamStockData) {
		// Create mapToPair transformation to get symbol as a key and (closingPrice, openingPrice, 1) as a value
		dStreamStockData.mapToPair(f -> new Tuple2<String, Tuple3<Double, Double, Integer>>
							(f._1, new Tuple3<Double, Double, Integer>(f._2.getPriceData().getClose(), f._2.getPriceData().getOpen(), 1)))
		// Applying reduce by key and window transformation on Stock data DStream with Window size 10 minutes and Sliding interval of 5 minutes
		.reduceByKeyAndWindow(new Function2<Tuple3<Double, Double, Integer>, Tuple3<Double, Double, Integer>, Tuple3<Double, Double, Integer>>(){
			private static final long serialVersionUID = 9046115012653714798L;

			// returning new tuple3 with total closingprice, openingprice and count
			@Override
			public Tuple3<Double, Double, Integer> call(Tuple3<Double, Double, Integer> v1, Tuple3<Double, Double, Integer> v2) throws Exception {
				return new Tuple3<Double, Double, Integer>(v1._1() + v2._1(), v1._2()+v2._2(), v1._3() + v2._3());
			}        	
		}, Durations.minutes(10), Durations.minutes(5))
		.foreachRDD(new VoidFunction<JavaPairRDD<String, Tuple3<Double, Double, Integer>>>(){
			private static final long serialVersionUID = 6915056127884666915L;

			// For each RDD, get average closing price by dividing total closing price by count for each stock, 
			// average opening price by dividing total opening price by count for each stock
			// calculate profit by subtracting opening price with closing price and displaying output with maximum profit
			@Override
			public void call(JavaPairRDD<String, Tuple3<Double, Double, Integer>> t) throws Exception {
				List<Tuple2<String, Tuple3<Double, Double, Integer>>> list = t.collect();
				
				double maxProfit = 0.0;
				String stockWithMaxProfit = null;
				for(Tuple2<String, Tuple3<Double, Double, Integer>> item : list)
				{
					double averageClosingPrice = item._2._1() / item._2._3();
					double averageOpeningPrice = item._2._2() / item._2._3();
					double profit = averageClosingPrice - averageOpeningPrice;
					if(profit > maxProfit)
					{
						maxProfit = profit;
						stockWithMaxProfit = item._1();
					}
				}
				System.out.println("max profit - " + stockWithMaxProfit + "profit : " + maxProfit);
			}
		});
	}

	private static void calculateStockWithHighTradedVolume(JavaPairDStream<String, Stock> dStreamStockData) {
		// Create mapToPair transformation to get symbol as a key and volume as a value
		dStreamStockData.mapToPair(f -> new Tuple2<String, Double>(f._1, f._2.getPriceData().getVolume()))
		// Applying reduce by key and window transformation on Stock data DStream with Window size 10 minutes and Sliding interval of 5 minutes
		.reduceByKeyAndWindow(new Function2<Double, Double, Double>(){
			private static final long serialVersionUID = 2186873845615696498L;

			// sum up volumes for each stock
			@Override
			public Double call(Double v1, Double v2) throws Exception {
				return v1 + v2;
			}        	
		}, Durations.minutes(10), Durations.minutes(5))
		.foreachRDD(new VoidFunction<JavaPairRDD<String, Double>>(){
			private static final long serialVersionUID = 4347402587547004436L;

			// For each RDD, get maximum traded volume of all the four stocks, and this is more likely to be purchased, hence display the same to output.
			@Override
			public void call(JavaPairRDD<String, Double> t) throws Exception {
				List<Tuple2<String, Double>> list = t.collect();
						
				double maxTradedVolume = 0.0;
				String stockWithMaxTradedVolume = null;
				for(Tuple2<String, Double> item : list)
				{
					if(item._2 > maxTradedVolume)
					{
						maxTradedVolume = item._2;
						stockWithMaxTradedVolume = item._1;
					}
					System.out.println("trading volume for Stock " + item._1 + " : " + item._2);
				}
				
				System.out.println("Stock with max trading volume more likely to be bought - " + stockWithMaxTradedVolume + " trading volume : " + maxTradedVolume);
				}
			});
	}

}
